import React from "react";
import { socialLinks } from "../../../data/socialLinks";
import { getIcon } from "../../../utils/iconMap";
import "./Footer.css";

const footerLinks = [
  { label: "Servicios", href: "#servicios" },
  { label: "Tecnologias", href: "#tecnologias" },
  { label: "Proyectos", href: "#proyectos" },
  { label: "Contacto", href: "#contacto" },
];

function Footer() {
  return (
    <footer className="footer">
      <div className="footer__inner">
        <div className="footer__brand">
          <a className="footer__logo" href="#inicio">
            <span>JD</span>
            Juan David
          </a>
          <p>Soluciones web y sistemas a medida para negocios que necesitan ordenar, crecer y vender mejor.</p>
        </div>

        <nav className="footer__nav" aria-label="Navegacion secundaria">
          {footerLinks.map((link) => (
            <a key={link.href} href={link.href}>
              {link.label}
            </a>
          ))}
        </nav>

        <div className="footer__socials">
          {socialLinks.map((link) => {
            const Icon = getIcon(link.icon);

            return (
              <a key={link.id} href={link.href} target="_blank" rel="noreferrer" aria-label={link.label}>
                <Icon aria-hidden="true" size={18} />
              </a>
            );
          })}
        </div>
      </div>
      <p className="footer__copyright">Copyright 2026 Juan David. Portfolio freelance.</p>
    </footer>
  );
}

export default Footer;
