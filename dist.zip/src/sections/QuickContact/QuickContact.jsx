import React from "react";
import ContactForm from "../../components/forms/ContactForm";
import "./QuickContact.css";

function QuickContact() {
  return (
    <section className="quick-contact section" id="contacto-rapido">
      <div className="container quick-contact__inner">
        <div className="quick-contact__copy">
          <span>Consulta rapida</span>
          <h2>Tenes una idea o un sistema trabado?</h2>
          <p>
            Mandame un resumen breve y puedo ayudarte a convertirlo en un alcance concreto, con prioridades y una ruta
            tecnica clara.
          </p>
        </div>
        <ContactForm
          compact
          title="Enviame un mensaje"
          subtitle="Con tres datos alcanza para empezar a conversar."
        />
      </div>
    </section>
  );
}

export default QuickContact;
