import React from "react";
import { ArrowRight, MessageCircle, Sparkles } from "lucide-react";
import Button from "../../components/common/Button";
import Badge from "../../components/common/Badge";
import heroVisual from "../../assets/images/hero-dashboard.png";
import { socialLinks } from "../../data/socialLinks";
import "./Hero.css";

function Hero() {
  const whatsappLink = socialLinks.find((link) => link.id === "whatsapp")?.href || "#contacto";

  return (
    <section className="hero section" id="inicio">
      <div className="hero__inner">
        <div className="hero__content animate-in">
          <Badge variant="accent" className="hero__badge">
            <Sparkles aria-hidden="true" size={16} />
            Disponible para proyectos freelance
          </Badge>
          <h1>Transformo ideas en soluciones digitales que impulsan negocios</h1>
          <p>
            Desarrollo sitios web, sistemas y aplicaciones modernas que optimizan procesos, mejoran la experiencia y
            generan resultados.
          </p>
          <div className="hero__actions">
            <Button href="#proyectos" size="lg" icon={ArrowRight}>
              Ver proyectos
            </Button>
            <Button href={whatsappLink} size="lg" variant="secondary" icon={MessageCircle}>
              Hablemos por WhatsApp
            </Button>
          </div>
          <div className="hero__metrics" aria-label="Resumen de experiencia">
            <span>
              <strong>Web</strong>
              Interfaces modernas
            </span>
            <span>
              <strong>APIs</strong>
              Backends claros
            </span>
            <span>
              <strong>Datos</strong>
              Sistemas ordenados
            </span>
          </div>
        </div>

        <div className="hero__visual animate-in animate-in--delay">
          <img src={heroVisual} alt="Dashboard oscuro con metricas y modulos de sistema digital" />
        </div>
      </div>
    </section>
  );
}

export default Hero;
