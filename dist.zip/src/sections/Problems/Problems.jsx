import React from "react";
import SectionHeader from "../../components/common/SectionHeader";
import ProblemCard from "../../components/cards/ProblemCard";
import { problems } from "../../data/problems";
import "./Problems.css";

function Problems() {
  return (
    <section className="problems section" id="problemas">
      <div className="container problems__inner">
        <SectionHeader
          align="left"
          eyebrow="Problemas"
          title="Cuando el negocio crece, la improvisacion empieza a costar"
          description="Estas son situaciones comunes que se pueden resolver con sistemas simples, claros y adaptados a la forma real de trabajar."
        />
        <div className="problems__grid">
          {problems.map((problem) => (
            <ProblemCard key={problem.id} problem={problem} />
          ))}
        </div>
      </div>
    </section>
  );
}

export default Problems;
