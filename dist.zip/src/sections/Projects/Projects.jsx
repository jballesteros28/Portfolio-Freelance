import React from "react";
import SectionHeader from "../../components/common/SectionHeader";
import ProjectCard from "../../components/cards/ProjectCard";
import { projects } from "../../data/projects";
import "./Projects.css";

function Projects() {
  return (
    <section className="projects section" id="proyectos">
      <div className="container">
        <SectionHeader
          eyebrow="Proyectos"
          title="Casos demo con foco en experiencias utiles y mantenibles"
          description="Una muestra de interfaces y sistemas orientados a resolver operaciones concretas con buena experiencia de uso."
        />
        <div className="projects__grid">
          {projects.map((project) => (
            <ProjectCard key={project.id} project={project} />
          ))}
        </div>
      </div>
    </section>
  );
}

export default Projects;
