import React from "react";
import SectionHeader from "../../components/common/SectionHeader";
import ProcessStep from "../../components/cards/ProcessStep";
import { processSteps } from "../../data/processSteps";
import "./Process.css";

function Process() {
  return (
    <section className="process section" id="proceso">
      <div className="container">
        <SectionHeader
          eyebrow="Proceso"
          title="Una forma de trabajo clara desde la primera conversacion"
          description="El objetivo es avanzar con foco, visibilidad y decisiones tecnicas simples de mantener."
        />
        <div className="process__grid">
          {processSteps.map((step) => (
            <ProcessStep key={step.id} step={step} />
          ))}
        </div>
      </div>
    </section>
  );
}

export default Process;
