import React from "react";
import ContactForm from "../../components/forms/ContactForm";
import Badge from "../../components/common/Badge";
import { socialLinks } from "../../data/socialLinks";
import { getIcon } from "../../utils/iconMap";
import "./AboutContact.css";

function AboutContact() {
  return (
    <section className="about-contact section" id="sobre-mi">
      <div className="container about-contact__inner">
        <div className="about-contact__content">
          <Badge variant="accent">Sobre mi</Badge>
          <h2>Hola, soy Juan David. Construyo soluciones digitales con mirada de negocio.</h2>
          <p>
            Me enfoco en transformar ideas, procesos desordenados y necesidades operativas en productos web claros:
            sitios, sistemas de gestion, APIs y bases de datos que una persona pueda usar todos los dias sin pelearse
            con la tecnologia.
          </p>
          <p>
            Trabajo con una combinacion de frontend moderno, backend solido y criterio practico para que cada entrega
            tenga sentido tecnico y aporte valor desde el primer uso.
          </p>

          <div className="about-contact__socials">
            {socialLinks.map((link) => {
              const Icon = getIcon(link.icon);

              return (
                <a key={link.id} href={link.href} target="_blank" rel="noreferrer" aria-label={link.label}>
                  <Icon aria-hidden="true" size={18} />
                  <span>{link.label}</span>
                </a>
              );
            })}
          </div>
        </div>

        <div id="contacto" className="about-contact__form">
          <ContactForm
            title="Hablemos de tu proyecto"
            subtitle="Dejame el contexto y te respondo con proximos pasos concretos."
          />
        </div>
      </div>
    </section>
  );
}

export default AboutContact;
