import React from "react";
import SectionHeader from "../../components/common/SectionHeader";
import ServiceCard from "../../components/cards/ServiceCard";
import { services } from "../../data/services";
import "./Services.css";

function Services() {
  return (
    <section className="services section" id="servicios">
      <div className="container">
        <SectionHeader
          eyebrow="Servicios"
          title="Soluciones digitales para ordenar y hacer crecer tu negocio"
          description="Cada servicio esta pensado para resolver necesidades reales: presencia online, gestion interna, automatizacion y productos listos para escalar."
        />
        <div className="services__grid">
          {services.map((service) => (
            <ServiceCard key={service.id} service={service} />
          ))}
        </div>
      </div>
    </section>
  );
}

export default Services;
